from setuptools import setup

setup(
    name="s1290080_learn",
    version="1.0.0",
    install_requires=['pandas', 'plotly', 'numpy', 're', 'pami'],
)
